<?php return array (
  'chats' => 'App\\Http\\Livewire\\Chats',
  'courses' => 'App\\Http\\Livewire\\Courses',
  'frontpage' => 'App\\Http\\Livewire\\Frontpage',
  'messengers' => 'App\\Http\\Livewire\\Messengers',
  'user-permissions' => 'App\\Http\\Livewire\\UserPermissions',
  'users' => 'App\\Http\\Livewire\\Users',
);